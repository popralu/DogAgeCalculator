package com.example.dogagecalculator

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
import android.widget.Toast


@SuppressLint("StaticFieldLeak")
lateinit var EnteredYearBorn : EditText
@SuppressLint("StaticFieldLeak")
lateinit var ActualAge : TextView




class MainActivity : AppCompatActivity() {



    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    val btnCalculate : Button = findViewById(R.id.btnCalculate)
        EnteredYearBorn  = findViewById(R.id.EnteredYearBorn)
        ActualAge  = findViewById(R.id.ActualAge)



        btnCalculate.setOnClickListener {
            val dateBirth = EnteredYearBorn.text.toString()
            val year : Int = Calendar.getInstance().get(Calendar.YEAR)

            if (dateBirth == "") {
                Toast.makeText(this, "Please enter a year", Toast.LENGTH_LONG).show()
            }
            else if (dateBirth > year.toString()) {
                Toast.makeText(this, "Entered year should be less than $year", Toast.LENGTH_LONG).show()
            }
            else {
                val petAge = year - dateBirth.toInt()
                ActualAge.text = "Your dog is $petAge years old"
            }

        }

        }

    }






